﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeData
{
   /* public class Menu
    {
        string EmpName { get; set; }
        string EmpNo { get; set; }
        string MoNo { get; set; }
        string City { get; set; }
        string Exp { get; set; }
        public void menu()
        {
            Console.WriteLine("1.Add new Employee");
            Console.WriteLine("2.Display All Employee");
            Console.WriteLine("3.Search Employee");
            Console.WriteLine("4.Remove Employee");
            Console.WriteLine("5.Exit");
        }
    }*/
}
